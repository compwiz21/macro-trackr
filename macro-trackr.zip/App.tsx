
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import HistoryView from './components/HistoryView';
import WorkoutLogger from './components/WorkoutLogger';
import FoodLogger from './components/FoodLogger';
import AICoach from './components/AICoach';
import Settings from './components/Settings';
import AccountSelector from './components/AccountSelector';
import { Tab, WorkoutSession, FoodEntry, WeightUnit, DailyGoals, UserProfile, WorkoutPlan } from './types';

const DEFAULT_GOALS: DailyGoals = {
  calories: 2600,
  protein: 180,
  carbs: 250,
  fat: 65
};

const COLORS = ['bg-red-500', 'bg-blue-600', 'bg-purple-600', 'bg-orange-600', 'bg-emerald-600'];

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [users, setUsers] = useState<UserProfile[]>([]);
  
  const [activeTab, setActiveTab] = useState<Tab>(Tab.DASHBOARD);
  const [sessions, setSessions] = useState<WorkoutSession[]>([]);
  const [foodEntries, setFoodEntries] = useState<FoodEntry[]>([]);
  const [isLogging, setIsLogging] = useState(false);
  const [preferredUnit, setPreferredUnit] = useState<WeightUnit>('kg');
  const [goals, setGoals] = useState<DailyGoals>(DEFAULT_GOALS);
  const [activePlan, setActivePlan] = useState<WorkoutPlan | null>(null);

  useEffect(() => {
    const savedUsers = localStorage.getItem('fitmacho_user_list');
    const savedActiveId = localStorage.getItem('fitmacho_active_user_id');
    if (savedUsers) {
      const parsedUsers: UserProfile[] = JSON.parse(savedUsers);
      setUsers(parsedUsers);
      if (savedActiveId) {
        const found = parsedUsers.find(u => u.id === savedActiveId);
        if (found && (found.rememberPassword || found.googleId)) {
          setCurrentUser(found);
        }
      }
    }
  }, []);

  useEffect(() => {
    if (!currentUser) return;
    const id = currentUser.id;
    const savedSessions = localStorage.getItem(`user_${id}_sessions`);
    const savedFood = localStorage.getItem(`user_${id}_food`);
    const savedUnit = localStorage.getItem(`user_${id}_unit`);
    const savedGoals = localStorage.getItem(`user_${id}_goals`);
    setSessions(savedSessions ? JSON.parse(savedSessions) : []);
    setFoodEntries(savedFood ? JSON.parse(savedFood) : []);
    setPreferredUnit((savedUnit as WeightUnit) || 'kg');
    setGoals(savedGoals ? JSON.parse(savedGoals) : DEFAULT_GOALS);
    localStorage.setItem('fitmacho_active_user_id', id);
  }, [currentUser]);

  useEffect(() => {
    if (currentUser) localStorage.setItem(`user_${currentUser.id}_sessions`, JSON.stringify(sessions));
  }, [sessions, currentUser]);

  useEffect(() => {
    if (currentUser) localStorage.setItem(`user_${currentUser.id}_food`, JSON.stringify(foodEntries));
  }, [foodEntries, currentUser]);

  useEffect(() => {
    if (currentUser) localStorage.setItem(`user_${currentUser.id}_unit`, preferredUnit);
  }, [preferredUnit, currentUser]);

  useEffect(() => {
    if (currentUser) localStorage.setItem(`user_${currentUser.id}_goals`, JSON.stringify(goals));
  }, [goals, currentUser]);

  const handleSelectUser = (user: UserProfile, remember: boolean = false) => {
    const updatedUsers = users.map(u => u.id === user.id ? { ...u, rememberPassword: remember } : u);
    setUsers(updatedUsers);
    localStorage.setItem('fitmacho_user_list', JSON.stringify(updatedUsers));
    setCurrentUser(updatedUsers.find(u => u.id === user.id) || user);
  };

  const handleCreateUser = (name: string, password?: string, remember: boolean = true) => {
    const exists = users.some(u => u.name.toLowerCase() === name.toLowerCase());
    if (exists) throw new Error("Warrior name already taken!");
    const newUser: UserProfile = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      password,
      rememberPassword: remember,
      avatarColor: COLORS[Math.floor(Math.random() * COLORS.length)]
    };
    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    localStorage.setItem('fitmacho_user_list', JSON.stringify(updatedUsers));
    setCurrentUser(newUser);
  };

  const handleUpdateUser = (updates: Partial<UserProfile>) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, ...updates };
    setCurrentUser(updatedUser);
    const updatedList = users.map(u => u.id === currentUser.id ? updatedUser : u);
    setUsers(updatedList);
    localStorage.setItem('fitmacho_user_list', JSON.stringify(updatedList));
  };

  const handleGoogleLogin = (googleProfile: { googleId: string, email: string, name: string }) => {
    let existingUser = users.find(u => u.googleId === googleProfile.googleId || u.email === googleProfile.email);
    if (existingUser) {
      if (!existingUser.googleId) {
        existingUser.googleId = googleProfile.googleId;
        const updatedUsers = users.map(u => u.id === existingUser!.id ? existingUser! : u);
        setUsers(updatedUsers);
        localStorage.setItem('fitmacho_user_list', JSON.stringify(updatedUsers));
      }
      setCurrentUser(existingUser);
    } else {
      const newUser: UserProfile = {
        id: Math.random().toString(36).substr(2, 9),
        name: googleProfile.name,
        email: googleProfile.email,
        googleId: googleProfile.googleId,
        avatarColor: COLORS[Math.floor(Math.random() * COLORS.length)]
      };
      const updatedUsers = [...users, newUser];
      setUsers(updatedUsers);
      localStorage.setItem('fitmacho_user_list', JSON.stringify(updatedUsers));
      setCurrentUser(newUser);
    }
  };

  const handleDeleteUser = (id: string) => {
    const updatedUsers = users.filter(u => u.id !== id);
    setUsers(updatedUsers);
    localStorage.setItem('fitmacho_user_list', JSON.stringify(updatedUsers));
    localStorage.removeItem(`user_${id}_sessions`);
    localStorage.removeItem(`user_${id}_food`);
    localStorage.removeItem(`user_${id}_unit`);
    localStorage.removeItem(`user_${id}_goals`);
    if (currentUser?.id === id) {
      setCurrentUser(null);
      localStorage.removeItem('fitmacho_active_user_id');
    }
  };

  const handleSwitchAccount = () => {
    setCurrentUser(null);
    localStorage.removeItem('fitmacho_active_user_id');
    setActiveTab(Tab.DASHBOARD);
  };

  const handleSaveSession = (session: WorkoutSession) => {
    setSessions(prev => [...prev, session]);
    setIsLogging(false);
    setActivePlan(null);
    setActiveTab(Tab.DASHBOARD);
  };

  const handleSelectPlan = (plan: WorkoutPlan) => {
    setActivePlan(plan);
    setIsLogging(true);
    setActiveTab(Tab.WORKOUT);
  };

  if (!currentUser) {
    return (
      <AccountSelector 
        users={users} 
        onSelectUser={handleSelectUser} 
        onCreateUser={handleCreateUser} 
        onDeleteUser={handleDeleteUser}
        onGoogleLogin={handleGoogleLogin}
      />
    );
  }

  const renderContent = () => {
    if (isLogging) {
      return (
        <WorkoutLogger 
          onSave={handleSaveSession} 
          onCancel={() => { setIsLogging(false); setActivePlan(null); }} 
          defaultUnit={preferredUnit}
          initialPlan={activePlan || undefined}
        />
      );
    }

    switch (activeTab) {
      case Tab.DASHBOARD:
        return (
          <Dashboard 
            sessions={sessions} 
            unit={preferredUnit} 
          />
        );
      case Tab.FUEL:
        return (
          <FoodLogger 
            entries={foodEntries} 
            onAdd={e => setFoodEntries(prev => [...prev, e])} 
            onRemove={id => setFoodEntries(prev => prev.filter(e => e.id !== id))}
            goals={goals}
          />
        );
      case Tab.WORKOUT:
        return (
          <div className="flex flex-col items-center justify-center min-h-[60vh] p-8 text-center space-y-8 animate-in zoom-in-95 duration-500 bg-black">
            <div className="relative">
               <div className="absolute -inset-4 bg-red-600 opacity-20 blur-xl rounded-full animate-pulse"></div>
               <div className="relative w-24 h-24 bg-red-600 rounded-[2rem] flex items-center justify-center transform rotate-12 shadow-2xl border border-white/20">
                 <DumbbellIcon size={48} className="text-white -rotate-12" />
               </div>
            </div>
            <div className="space-y-3">
              <h2 className="text-4xl font-oswald font-bold uppercase italic leading-none tracking-tighter text-white">Ready to <span className="text-red-500 underline decoration-red-900/10">GRIND?</span></h2>
              <p className="text-zinc-400 text-xs font-bold uppercase tracking-[0.2em] max-w-[200px] mx-auto leading-relaxed">Focus up, {currentUser.name}. Make every rep count.</p>
            </div>
            <button 
              onClick={() => setIsLogging(true)}
              className="group relative w-full overflow-hidden rounded-[2rem] bg-red-600 p-6 transition-all hover:scale-105 active:scale-95 shadow-xl shadow-red-900/20"
            >
              <div className="relative flex items-center justify-center gap-2 text-2xl font-oswald font-bold text-white uppercase tracking-wider">
                Start Training
              </div>
            </button>
          </div>
        );
      case Tab.HISTORY:
        return <HistoryView sessions={sessions} />;
      case Tab.COACH:
        return <AICoach sessions={sessions} onSelectPlan={handleSelectPlan} />;
      case Tab.SETTINGS:
        return (
          <Settings 
            goals={goals} 
            onUpdateGoals={setGoals} 
            unit={preferredUnit} 
            onUpdateUnit={setPreferredUnit} 
            onSwitchAccount={handleSwitchAccount}
            currentUser={currentUser}
            onUpdateUser={handleUpdateUser}
          />
        );
      default:
        return <Dashboard sessions={sessions} unit={preferredUnit} />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab} currentUser={currentUser}>
      {renderContent()}
    </Layout>
  );
};

const DumbbellIcon = ({size, className}: {size: number, className?: string}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="m6.5 6.5 11 11"/><path d="m10 10 5.5 5.5"/><path d="m3 21 3-3"/><path d="m3 3 3 3"/><path d="m18 18 3 3"/><path d="m18 6 3-3"/><path d="M2.5 7 7 2.5"/><path d="M17 21.5 21.5 17"/><path d="M11.5 15.5 15.5 11.5"/><path d="M15.5 11.5 11.5 15.5"/><path d="M2.5 7.5 7.5 2.5"/><path d="M16.5 21.5 21.5 16.5"/><path d="m3.5 17.5 3 3"/><path d="m17.5 3.5 3 3"/>
  </svg>
);

export default App;
