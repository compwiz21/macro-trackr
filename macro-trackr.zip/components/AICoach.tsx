
import React, { useState, useRef, useEffect } from 'react';
import { getAIAdvice, handleKeyReauth, checkHasKey } from '../services/geminiService';
import { WorkoutSession, WorkoutPlan } from '../types';
import { Send, Bot, User, Loader2, Zap, CheckCircle2, Phone, PhoneOff, Mic, MicOff, Volume2 } from 'lucide-react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

interface AICoachProps {
  sessions: WorkoutSession[];
  onSelectPlan: (plan: WorkoutPlan) => void;
}

interface Message {
  role: 'user' | 'ai';
  content: string;
  plan?: string[];
}

const AICoach: React.FC<AICoachProps> = ({ sessions, onSelectPlan }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'ai', content: "Systems check complete. I'm Coach Trackr. Whether you're optimizing macros or hunting a new PR, I'm here to ensure total precision. What's our objective today?" }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isLive, setIsLive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Live API Refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputNodeRef = useRef<GainNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const decodeBase64 = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const encodePCM = (data: Float32Array): string => {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    let binary = '';
    const bytes = new Uint8Array(int16.buffer);
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const startLiveCall = async () => {
    const hasKey = await checkHasKey();
    if (!hasKey) {
      await handleKeyReauth();
      return;
    }

    setIsConnecting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const outputCtx = audioContextRef.current;
      outputNodeRef.current = outputCtx.createGain();
      outputNodeRef.current.connect(outputCtx.destination);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsLive(true);
            const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const base64Pcm = encodePCM(inputData);
              sessionPromise.then(s => s.sendRealtimeInput({ media: { data: base64Pcm, mimeType: 'audio/pcm;rate=16000' } }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && outputCtx) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const buffer = await decodeAudioData(decodeBase64(audioData), outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputNodeRef.current!);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error("Live Error:", e);
            stopLiveCall();
          },
          onclose: () => stopLiveCall(),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: "You are Coach Trackr. Be data-driven, motivating, and focus on high-performance results. Keep responses short and tactical. You are in a live voice session with a Macro Trackr athlete."
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err: any) {
      console.error("Failed to start live call:", err);
      setIsConnecting(false);
      if (err.message?.includes("Requested entity was not found")) {
        await handleKeyReauth();
      }
    }
  };

  const stopLiveCall = () => {
    if (sessionRef.current) {
      try { sessionRef.current.close(); } catch (e) {}
    }
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    if (audioContextRef.current) {
      audioContextRef.current.close();
    }
    setIsLive(false);
    setIsConnecting(false);
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsTyping(true);

    const advice = await getAIAdvice(sessions, userMsg);
    let finalContent = advice || 'Error connecting to Coach Trackr.';
    let exercises: string[] | undefined;
    
    const planMatch = finalContent.match(/<plan>(.*?)<\/plan>/);
    if (planMatch) {
      exercises = planMatch[1].split('|').map(e => e.trim());
      finalContent = finalContent.replace(/<plan>.*?<\/plan>/, '').trim();
    }

    setMessages(prev => [...prev, { role: 'ai', content: finalContent, plan: exercises }]);
    setIsTyping(false);
  };

  const renderFormattedContent = (text: string) => {
    const lines = text.split('\n');
    return (
      <div className="flex flex-col gap-2.5">
        {lines.map((line, idx) => {
          if (line.trim() === '---') return <div key={idx} className="h-px bg-zinc-800 my-2" />;
          if (line.startsWith('###')) {
            return (
              <h4 key={idx} className="text-[11px] font-oswald font-bold text-red-500 uppercase tracking-wider mt-3 mb-1">
                {line.replace('###', '').trim()}
              </h4>
            );
          }
          if (line.trim().startsWith('*') || line.trim().startsWith('-')) {
            const content = line.replace(/^[*|-]/, '').trim();
            return (
              <div key={idx} className="flex gap-2 pl-2">
                <span className="text-red-600 font-bold">•</span>
                <span className="flex-1">{parseBold(content)}</span>
              </div>
            );
          }
          if (!line.trim()) return <div key={idx} className="h-1" />;
          return <p key={idx}>{parseBold(line)}</p>;
        })}
      </div>
    );
  };

  const parseBold = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-bold text-white text-shadow-sm">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950">
      <div className="p-6 bg-zinc-900/50 border-b border-zinc-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-red-600 flex items-center justify-center shadow-lg shadow-red-900/40 relative">
            <Zap size={20} className="text-white fill-white" />
            {isLive && <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-zinc-950 animate-pulse"></span>}
          </div>
          <div>
            <h2 className="text-lg font-oswald font-bold leading-none uppercase tracking-tight text-white">Coach Trackr</h2>
            <div className="flex items-center gap-1.5 mt-1">
              <span className={`w-1.5 h-1.5 rounded-full ${isLive ? 'bg-green-500 animate-pulse' : 'bg-zinc-600'}`}></span>
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">{isLive ? 'Trackr Live Active' : 'Performance AI'}</span>
            </div>
          </div>
        </div>
        
        <button 
          onClick={isLive ? stopLiveCall : startLiveCall}
          disabled={isConnecting}
          className={`flex items-center gap-2 px-4 py-2 rounded-full font-bold uppercase text-[10px] tracking-widest transition-all ${
            isLive 
              ? 'bg-red-600 text-white shadow-lg shadow-red-900/40 animate-pulse' 
              : 'bg-zinc-800 text-zinc-400 border border-zinc-700 hover:text-white hover:border-red-500'
          }`}
        >
          {isConnecting ? <Loader2 size={14} className="animate-spin" /> : isLive ? <PhoneOff size={14} /> : <Phone size={14} />}
          {isConnecting ? 'Linking...' : isLive ? 'End Call' : 'Trackr Live'}
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
        {isLive ? (
          <div className="flex flex-col items-center justify-center h-full space-y-8 animate-in fade-in zoom-in-95 duration-500">
            <div className="relative">
              <div className="absolute inset-0 bg-red-600 rounded-full opacity-20 animate-ping"></div>
              <div className="relative w-32 h-32 bg-red-600 rounded-full flex items-center justify-center shadow-2xl shadow-red-900/50">
                <Volume2 size={48} className="text-white" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-2xl font-oswald font-bold text-white uppercase italic tracking-tighter">Live with Trackr</h3>
              <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em]">Telemetry active. Speak now.</p>
            </div>
            <div className="flex gap-4">
              <div className="flex items-center gap-2 px-4 py-2 bg-zinc-900 rounded-2xl border border-zinc-800">
                <Mic size={14} className="text-red-500" />
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Mic Active</span>
              </div>
            </div>
          </div>
        ) : (
          <>
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[92%] flex flex-col gap-2 ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                  <div className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mt-1 ${
                      m.role === 'user' ? 'bg-zinc-800 text-zinc-400' : 'bg-red-600/20 text-red-500 border border-red-500/30'
                    }`}>
                      {m.role === 'user' ? <User size={16} /> : <Bot size={16} />}
                    </div>
                    <div className={`p-4 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap transition-all shadow-xl ${
                      m.role === 'user' 
                        ? 'bg-zinc-800 text-white rounded-tr-none' 
                        : 'bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-tl-none'
                    }`}>
                      {m.role === 'ai' ? renderFormattedContent(m.content) : m.content}
                    </div>
                  </div>
                  
                  {m.plan && (
                    <div className="ml-11 mt-1 p-4 bg-red-600/10 border border-red-500/30 rounded-2xl w-full max-w-[280px] animate-in slide-in-from-left-2 duration-500">
                      <p className="text-[10px] font-bold text-red-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                        <CheckCircle2 size={12} /> Sync tactics to Training?
                      </p>
                      <div className="flex flex-wrap gap-1.5 mb-4">
                        {m.plan.map((ex, idx) => (
                          <span key={idx} className="px-2 py-0.5 bg-black/40 rounded-md text-[9px] font-bold text-zinc-400 border border-zinc-800 uppercase">
                            {ex}
                          </span>
                        ))}
                      </div>
                      <button 
                        onClick={() => onSelectPlan({ title: "Coach Trackr Tactics", exercises: m.plan! })}
                        className="w-full py-2.5 bg-red-600 text-white font-oswald font-bold uppercase tracking-widest text-xs rounded-xl hover:bg-red-700 transition-colors shadow-lg active:scale-95"
                      >
                        Execute Plan
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-2xl rounded-tl-none flex items-center gap-2">
                  <Loader2 className="animate-spin text-red-500" size={16} />
                  <span className="text-xs text-zinc-500 font-bold uppercase tracking-widest">Optimizing advice...</span>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <div className="p-6 bg-zinc-950 border-t border-zinc-900">
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLive}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={isLive ? "Speak now..." : "Request a tactical plan or form analysis..."}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl py-4 pl-4 pr-14 text-sm text-white focus:outline-none focus:ring-1 focus:ring-red-500/50 resize-none min-h-[56px] max-h-32 disabled:opacity-50"
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || isTyping || isLive}
            className="absolute right-3 bottom-3 p-2.5 bg-red-600 text-white rounded-xl shadow-lg shadow-red-900/20 hover:bg-red-700 disabled:bg-zinc-800 disabled:text-zinc-600 transition-all"
          >
            <Send size={18} />
          </button>
        </div>
        <p className="text-[10px] text-center text-zinc-600 mt-4 uppercase font-bold tracking-widest">
          Coach Trackr provides performance AI guidance. Prioritize safety.
        </p>
      </div>
    </div>
  );
};

export default AICoach;
