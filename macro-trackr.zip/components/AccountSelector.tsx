
import React, { useState, useEffect, useRef } from 'react';
import { UserProfile } from '../types';
import { Plus, User, ArrowRight, Zap, X, Lock, Eye, EyeOff, ShieldCheck, LogIn, RefreshCcw } from 'lucide-react';

declare const google: any;

const GOOGLE_CLIENT_ID = "184482078531-nn5rmq4i7mbtiklk9pkasohop55j3agh.apps.googleusercontent.com";

interface AccountSelectorProps {
  users: UserProfile[];
  onSelectUser: (user: UserProfile, remember?: boolean) => void;
  onCreateUser: (name: string, password?: string, remember?: boolean) => void;
  onDeleteUser: (id: string) => void;
  onGoogleLogin: (profile: { googleId: string, email: string, name: string }) => void;
}

const AccountSelector: React.FC<AccountSelectorProps> = ({ users, onSelectUser, onCreateUser, onDeleteUser, onGoogleLogin }) => {
  const [view, setView] = useState<'LIST' | 'SIGN_UP' | 'SIGN_IN'>('LIST');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  
  const [loggingInUser, setLoggingInUser] = useState<UserProfile | null>(null);
  const [error, setError] = useState('');
  const [isGoogleReady, setIsGoogleReady] = useState(false);
  const [initAttempts, setInitAttempts] = useState(0);
  
  const googleBtnRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let interval: number;

    const initGoogle = () => {
      if (typeof google !== 'undefined' && google.accounts) {
        try {
          google.accounts.id.initialize({
            client_id: GOOGLE_CLIENT_ID,
            callback: handleGoogleResponse,
            auto_select: false,
            cancel_on_tap_outside: true,
          });
          
          if (googleBtnRef.current) {
            google.accounts.id.renderButton(googleBtnRef.current, {
              theme: "filled_black",
              size: "large",
              width: "320",
              text: "continue_with",
              shape: "pill"
            });
            setIsGoogleReady(true);
            setError('');
          }
        } catch (err) {
          console.error("Google Init Error:", err);
        }
      } else if (initAttempts < 10) {
        interval = window.setTimeout(() => setInitAttempts(prev => prev + 1), 500);
      }
    };

    initGoogle();
    return () => clearTimeout(interval);
  }, [view, loggingInUser, initAttempts]);

  const handleGoogleResponse = (response: any) => {
    try {
      if (response.error) {
        setError(`Google Auth Error: ${response.error}. Check console for details.`);
        return;
      }
      const payload = JSON.parse(atob(response.credential.split('.')[1]));
      onGoogleLogin({
        googleId: payload.sub,
        email: payload.email,
        name: payload.name
      });
    } catch (err) {
      console.error("Google Login Error:", err);
      setError("Failed to verify Google Identity. Please try again.");
    }
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && password.trim()) {
      try {
        onCreateUser(name.trim(), password.trim(), rememberMe);
        resetForm();
      } catch (err: any) {
        setError(err.message || "Failed to initialize profile");
      }
    } else {
      setError('Athlete name and access code required');
    }
  };

  const handleManualSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.name.toLowerCase() === name.trim().toLowerCase());
    if (user && user.password === password) {
      onSelectUser(user, rememberMe);
      resetForm();
    } else {
      setError('Invalid Athlete or Access Code');
    }
  };

  const handleQuickLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loggingInUser && password === loggingInUser.password) {
      onSelectUser(loggingInUser, rememberMe);
      resetForm();
    } else {
      setError('Invalid Access Code');
      setPassword('');
    }
  };

  const resetForm = () => {
    setName('');
    setPassword('');
    setError('');
    setView('LIST');
    setLoggingInUser(null);
  };

  const onUserClick = (user: UserProfile) => {
    if (user.googleId) {
      onSelectUser(user);
    } else if (user.password && !user.rememberPassword) {
      setLoggingInUser(user);
      setRememberMe(true);
    } else {
      onSelectUser(user);
    }
  };

  return (
    <div className="flex flex-col h-full bg-black p-8 justify-center animate-in fade-in duration-700 relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] w-72 h-72 bg-red-600/10 blur-[120px] rounded-full"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-72 h-72 bg-red-600/5 blur-[120px] rounded-full"></div>

      <div className="text-center mb-10 z-10">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-red-600 rounded-3xl mb-6 shadow-2xl shadow-red-900/40 rotate-3 transform transition-transform hover:rotate-0">
          <Zap size={40} className="text-white fill-white" />
        </div>
        <h1 className="text-4xl font-oswald font-bold tracking-tighter text-white uppercase italic leading-none">
          {loggingInUser ? 'AUTHORIZE' : view === 'SIGN_UP' ? 'NEW' : view === 'SIGN_IN' ? 'WELCOME' : 'IDENTIFY'} 
          <span className="text-red-500"> {loggingInUser ? 'SESSION' : view === 'SIGN_UP' ? 'ATHLETE' : view === 'SIGN_IN' ? 'BACK' : 'TRACKR'}</span>
        </h1>
        <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em] mt-3">
          {loggingInUser ? `Confirm telemetry for ${loggingInUser.name}` : view === 'LIST' ? 'Select profile to begin tracking' : 'Provide your athlete credentials'}
        </p>
      </div>

      <div className="space-y-4 max-h-[55vh] overflow-y-auto pr-2 custom-scrollbar z-10">
        {view === 'LIST' && !loggingInUser && (
          <>
            {users.length > 0 && (
              <div className="space-y-3 mb-6">
                <p className="text-[9px] font-bold text-zinc-600 uppercase tracking-[0.3em] ml-1">Quick Access</p>
                {users.map((user) => (
                  <div key={user.id} className="group relative">
                    <button
                      onClick={() => onUserClick(user)}
                      className="w-full flex items-center justify-between p-5 bg-zinc-900/40 border border-zinc-800/60 rounded-3xl hover:border-red-500/50 transition-all hover:bg-zinc-800/80 group active:scale-95 shadow-lg backdrop-blur-sm"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-2xl ${user.avatarColor || 'bg-zinc-800'} flex items-center justify-center text-white font-oswald font-bold text-xl shadow-inner`}>
                          {user.name[0].toUpperCase()}
                        </div>
                        <div className="text-left">
                          <h3 className="font-oswald font-bold text-lg uppercase tracking-tight text-white group-hover:text-red-500 transition-colors">
                            {user.name}
                          </h3>
                          <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-1">
                            {user.googleId ? (
                              <span className="text-blue-500 flex items-center gap-1">Linked Google Account</span>
                            ) : user.rememberPassword ? (
                              <span className="text-green-500 flex items-center gap-1"><ShieldCheck size={8} /> Authorized</span>
                            ) : (
                              <><Lock size={8} /> Protected Account</>
                            )}
                          </p>
                        </div>
                      </div>
                      <ArrowRight className="text-zinc-700 group-hover:text-red-500 transition-colors" size={20} />
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); onDeleteUser(user.id); }}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-zinc-800 rounded-full flex items-center justify-center text-zinc-500 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity border border-zinc-700 shadow-xl"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3 mb-6">
              <button
                onClick={() => { setView('SIGN_UP'); setError(''); }}
                className="flex flex-col items-center justify-center gap-2 p-6 bg-zinc-900/30 border-2 border-dashed border-zinc-800 rounded-3xl text-zinc-500 hover:text-white hover:border-zinc-600 transition-all group"
              >
                <Plus size={24} className="group-hover:scale-110 transition-transform text-red-500" />
                <span className="font-bold uppercase tracking-widest text-[10px]">Add Athlete</span>
              </button>
              <button
                onClick={() => { setView('SIGN_IN'); setError(''); }}
                className="flex flex-col items-center justify-center gap-2 p-6 bg-zinc-900/30 border-2 border-dashed border-zinc-800 rounded-3xl text-zinc-500 hover:text-white hover:border-zinc-600 transition-all group"
              >
                <LogIn size={24} className="group-hover:scale-110 transition-transform text-blue-500" />
                <span className="font-bold uppercase tracking-widest text-[10px]">Sign In</span>
              </button>
            </div>

            <div className="relative py-4">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-zinc-800"></div></div>
              <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest"><span className="bg-black px-4 text-zinc-600">SECURE LOGIN</span></div>
            </div>

            <div className="flex flex-col gap-3">
              <div ref={googleBtnRef} id="google-signin-btn-container" className="min-h-[44px]"></div>
              
              {!isGoogleReady && (
                <div className="text-center space-y-3">
                  <p className="text-[9px] text-zinc-600 font-bold uppercase tracking-widest">Initializing identity services...</p>
                </div>
              )}

              {error && (
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-2xl text-[10px] text-red-500 font-bold uppercase tracking-widest text-center">
                  {error}
                </div>
              )}
            </div>
          </>
        )}

        {(view === 'SIGN_UP' || view === 'SIGN_IN') && !loggingInUser && (
          <form onSubmit={view === 'SIGN_UP' ? handleCreate : handleManualSignIn} className="space-y-4 animate-in slide-in-from-bottom-4 duration-300 bg-zinc-900/30 p-6 rounded-[2.5rem] border border-zinc-800 shadow-2xl backdrop-blur-md">
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Athlete Name</label>
                <input
                  autoFocus
                  className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl p-4 text-white font-bold placeholder:text-zinc-700 outline-none focus:border-red-500/50 transition-colors"
                  placeholder="e.g. CHAMP"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Access Code</label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl p-4 text-white font-bold placeholder:text-zinc-700 outline-none focus:border-red-500/50 transition-colors"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
            </div>

            <label className="flex items-center gap-3 px-1 cursor-pointer group">
              <div 
                onClick={() => setRememberMe(!rememberMe)}
                className={`w-5 h-5 rounded-md border transition-all flex items-center justify-center ${rememberMe ? 'bg-red-600 border-red-600' : 'bg-zinc-800 border-zinc-700 group-hover:border-zinc-500'}`}
              >
                {rememberMe && <Zap size={12} className="text-white fill-white" />}
              </div>
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest group-hover:text-zinc-300 transition-colors">Remember athlete</span>
            </label>
            
            <div className="flex flex-col gap-2 pt-2">
              <button 
                type="submit"
                className={`w-full ${view === 'SIGN_UP' ? 'bg-red-600' : 'bg-blue-600'} text-white font-oswald font-bold py-4 rounded-2xl uppercase tracking-widest hover:brightness-110 transition-all shadow-lg shadow-black/40 active:scale-95`}
              >
                {view === 'SIGN_UP' ? 'Initialize Trackr' : 'Access Trackr'}
              </button>
              
              <button 
                type="button"
                onClick={resetForm}
                className="w-full bg-zinc-800/50 text-zinc-400 font-bold py-4 rounded-2xl uppercase tracking-widest hover:bg-zinc-800 active:scale-95 transition-all mt-2"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {loggingInUser && (
          <form onSubmit={handleQuickLogin} className="space-y-4 animate-in zoom-in-95 duration-300 bg-zinc-900/30 p-6 rounded-[2.5rem] border border-zinc-800 shadow-2xl backdrop-blur-md">
            <div className="flex items-center gap-3 mb-2 px-1">
              <div className={`w-10 h-10 rounded-xl ${loggingInUser.avatarColor} flex items-center justify-center text-white font-oswald font-bold text-base shadow-lg`}>
                {loggingInUser.name[0].toUpperCase()}
              </div>
              <span className="font-oswald font-bold uppercase text-white text-xl tracking-wider">{loggingInUser.name}</span>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Confirm Access Code</label>
              <div className="relative">
                <input
                  autoFocus
                  type="password"
                  className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl p-4 text-white font-bold placeholder:text-zinc-700 outline-none focus:border-red-500/50 transition-colors"
                  placeholder="Access Code"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button 
                type="submit"
                className="w-full bg-red-600 text-white font-oswald font-bold py-4 rounded-2xl uppercase tracking-widest hover:bg-red-700 transition-colors shadow-lg shadow-red-900/20 active:scale-95"
              >
                Unlock Trackr
              </button>
              <button 
                type="button"
                onClick={resetForm}
                className="w-full bg-zinc-800/50 text-zinc-400 font-bold py-4 rounded-2xl uppercase tracking-widest hover:bg-zinc-800 active:scale-95"
              >
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>

      <div className="mt-12 text-center opacity-30 z-10">
        <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-zinc-500 italic">Trackr Protocol v4.0.0</p>
      </div>
    </div>
  );
};

export default AccountSelector;
