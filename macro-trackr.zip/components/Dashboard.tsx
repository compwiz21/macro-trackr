
import React, { useMemo, useState } from 'react';
import { WorkoutSession, WeightUnit } from '../types';
import { Activity, Flame, Trophy, TrendingUp, BarChart3, Play, Loader2, X, Download } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { generateMotivationVideo } from '../services/geminiService';
import { GoogleGenAI } from '@google/genai';

interface DashboardProps {
  sessions: WorkoutSession[];
  unit: WeightUnit;
}

const Dashboard: React.FC<DashboardProps> = ({ sessions, unit }) => {
  const [isVideoLoading, setIsVideoLoading] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [loadingStep, setLoadingStep] = useState('');

  const currentStreak = useMemo(() => {
    if (sessions.length === 0) return 0;
    const uniqueDates: string[] = Array.from(new Set<string>(
      sessions.map(s => s.date.split('T')[0])
    )).sort((a: string, b: string) => new Date(b).getTime() - new Date(a).getTime());
    
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    
    if (uniqueDates[0] !== today && uniqueDates[0] !== yesterday) return 0;
    
    let streak = 1;
    for (let i = 0; i < uniqueDates.length - 1; i++) {
      const current = new Date(uniqueDates[i]);
      const next = new Date(uniqueDates[i + 1]);
      const diffDays = Math.ceil(Math.abs(current.getTime() - next.getTime()) / (1000 * 60 * 60 * 24));
      if (diffDays === 1) streak++; else break;
    }
    return streak;
  }, [sessions]);

  const totalVolume = useMemo(() => {
    return sessions.reduce((acc, s) => {
      let sessionVol = s.totalVolume;
      if (s.unit !== unit) {
        if (unit === 'lbs' && s.unit === 'kg') sessionVol = s.totalVolume * 2.20462;
        if (unit === 'kg' && s.unit === 'lbs') sessionVol = s.totalVolume / 2.20462;
      }
      return acc + sessionVol;
    }, 0);
  }, [sessions, unit]);

  const chartData = useMemo(() => {
    const last7 = [...sessions]
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(-7)
      .map(s => ({
        name: new Date(s.date).toLocaleDateString('en-US', { weekday: 'short' }),
        volume: Math.round(s.totalVolume)
      }));
    return last7.length > 0 ? last7 : [{ name: 'N/A', volume: 0 }];
  }, [sessions]);

  const totalWorkouts = sessions.length;
  const avgDuration = totalWorkouts > 0 ? Math.round(sessions.reduce((acc, s) => acc + s.durationMinutes, 0) / totalWorkouts) : 0;

  const handleGenerateMotivation = async () => {
    if (window.aistudio && typeof window.aistudio.hasSelectedApiKey === 'function') {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        if (typeof window.aistudio.openSelectKey === 'function') {
          await window.aistudio.openSelectKey();
        }
      }
    }

    setIsVideoLoading(true);
    setLoadingStep('Initializing high-perf render...');
    
    try {
      const steps = [
        'Calculating volumetric gains...',
        'Syncing Trackr telemetry...',
        'Rendering absolute iron...',
        'Compiling high-energy visuals...',
        'Finalizing the session...'
      ];
      
      let stepIdx = 0;
      const stepInterval = setInterval(() => {
        setLoadingStep(steps[stepIdx % steps.length]);
        stepIdx++;
      }, 5000);

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let operation = await generateMotivationVideo(`Cinematic Macro Trackr performance video: athlete with ${currentStreak} day streak, crushing heavy reps, epic lighting, precision movements.`);
      
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 5000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      clearInterval(stepInterval);
      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const blob = await response.blob();
        setVideoUrl(URL.createObjectURL(blob));
      }
    } catch (error: any) {
      console.error("Video failed:", error);
      if (error.message?.includes("Requested entity was not found")) {
        if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
          await window.aistudio.openSelectKey();
        }
      }
    } finally {
      setIsVideoLoading(false);
      setLoadingStep('');
    }
  };

  return (
    <div className="p-6 space-y-6 bg-black min-h-full text-white">
      <section>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-oswald font-bold flex items-center gap-2 uppercase italic tracking-tighter">
            <TrendingUp className="text-red-500" /> TRACKR PERFORMANCE
          </h2>
          <button 
            onClick={handleGenerateMotivation}
            className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-full text-[9px] font-bold uppercase tracking-widest text-red-500 hover:bg-zinc-800 transition-all shadow-lg"
          >
            <Play size={10} className="fill-red-500" /> Trackr Vision™
          </button>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-zinc-900/50 p-4 rounded-3xl border border-zinc-800/60 flex flex-col justify-between h-32 backdrop-blur-sm shadow-xl">
            <Activity className="text-red-500 mb-2" size={20} />
            <div>
              <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Total Sessions</p>
              <p className="text-2xl font-oswald font-bold text-white leading-none">{totalWorkouts}</p>
            </div>
          </div>
          <div className="bg-zinc-900/50 p-4 rounded-3xl border border-zinc-800/60 flex flex-col justify-between h-32 backdrop-blur-sm shadow-xl">
            <Flame className="text-orange-500 mb-2" size={20} />
            <div>
              <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Net Volume</p>
              <p className="text-2xl font-oswald font-bold text-white leading-none">{Math.round(totalVolume).toLocaleString()} <span className="text-[10px] uppercase font-inter opacity-40">{unit}</span></p>
            </div>
          </div>
          <div className="bg-zinc-900/50 p-4 rounded-3xl border border-zinc-800/60 flex flex-col justify-between h-32 backdrop-blur-sm shadow-xl">
            <Trophy className="text-yellow-500 mb-2" size={20} />
            <div>
              <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Intensity Avg</p>
              <p className="text-2xl font-oswald font-bold text-white leading-none">{avgDuration} <span className="text-[10px] font-inter opacity-40">MIN</span></p>
            </div>
          </div>
          <div className="bg-gradient-to-br from-red-600 to-red-900 p-4 rounded-3xl shadow-2xl flex flex-col justify-between h-32 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-10 -rotate-12 group-hover:rotate-0 transition-transform duration-700">
               <TrendingUp size={80} />
            </div>
            <div className="text-white/80 relative z-10"><TrendingUp size={20} /></div>
            <div className="relative z-10">
              <p className="text-[10px] text-red-100 uppercase tracking-[0.2em] font-bold">Active Streak</p>
              <p className="text-3xl font-oswald font-bold text-white uppercase italic tracking-tighter leading-none">
                {currentStreak} {currentStreak === 1 ? 'DAY' : 'DAYS'}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-zinc-900/50 p-6 rounded-[2.5rem] border border-zinc-800/60 shadow-2xl backdrop-blur-md">
          <div className="flex justify-between items-center mb-6">
             <div className="flex items-center gap-2">
               <BarChart3 className="text-red-500" size={18} />
               <h3 className="text-[10px] font-bold text-white uppercase tracking-widest">Growth Telemetry</h3>
             </div>
             <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest">Last 7 Sessions</span>
          </div>
          
          <div className="h-48 w-full -ml-6">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorVol" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#dc2626" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#dc2626" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#333" opacity={0.1} />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#4b5563', fontSize: 10, fontWeight: 'bold'}}
                  dy={10}
                />
                <Tooltip 
                  contentStyle={{backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '12px', fontSize: '10px', fontWeight: 'bold', color: '#fff'}}
                  itemStyle={{color: '#ef4444'}}
                  cursor={{stroke: '#dc2626', strokeWidth: 1}}
                />
                <Area 
                  type="monotone" 
                  dataKey="volume" 
                  stroke="#dc2626" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorVol)" 
                  animationDuration={1500}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Video Generation Overlays */}
      {isVideoLoading && (
        <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-500">
          <div className="relative w-24 h-24 mb-8">
            <div className="absolute inset-0 border-4 border-red-600/20 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-t-red-600 rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
               <Play size={24} className="text-red-500 animate-pulse" />
            </div>
          </div>
          <h2 className="text-3xl font-oswald font-bold text-white uppercase italic tracking-tighter mb-4">Generating Visual Motivation</h2>
          <p className="text-zinc-500 text-xs font-bold uppercase tracking-[0.2em] max-w-xs">{loadingStep}</p>
        </div>
      )}

      {videoUrl && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col animate-in zoom-in-95 duration-300">
          <div className="p-6 flex justify-between items-center border-b border-zinc-900">
            <h3 className="text-lg font-oswald font-bold text-white uppercase italic">Trackr Vision Session</h3>
            <button onClick={() => setVideoUrl(null)} className="p-2 text-zinc-500 hover:text-white"><X /></button>
          </div>
          <div className="flex-1 flex items-center justify-center p-6 bg-black">
            <video 
              src={videoUrl} 
              autoPlay 
              loop 
              controls 
              className="max-w-full max-h-full rounded-3xl shadow-[0_0_50px_rgba(220,38,38,0.3)] border border-zinc-800"
            />
          </div>
          <div className="p-6 border-t border-zinc-900 flex gap-4 bg-zinc-950">
            <a 
              href={videoUrl} 
              download="trackr-motivation.mp4"
              className="flex-1 py-4 bg-red-600 text-white font-oswald font-bold uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 hover:bg-red-700 transition-colors shadow-xl shadow-red-900/20"
            >
              <Download size={20} /> Store Progress
            </a>
          </div>
        </div>
      )}

      <section className="bg-zinc-900/30 p-5 rounded-[2rem] border border-zinc-800/50 overflow-hidden relative shadow-lg">
        <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
          <DumbbellIcon size={80} />
        </div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1.5 h-4 bg-red-600 rounded-full"></div>
          <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Coach's Directive</h3>
        </div>
        <p className="text-sm leading-relaxed text-zinc-300 italic font-medium">
          {currentStreak > 0 
            ? `"${currentStreak} DAYS OF PROGRESS. DO NOT BREAK THE CHAIN. THE MACRO TRACKR PROTOCOL REQUIRES ABSOLUTE CONSISTENCY!"`
            : `"STARTING FROM ZERO? GOOD. THAT'S WHERE LEGENDS ARE CALIBRATED. GET IN THERE AND CRUSH THAT FIRST REP!"`}
        </p>
      </section>
    </div>
  );
};

const DumbbellIcon = ({size}: {size: number}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m6.5 6.5 11 11"/><path d="m10 10 5.5 5.5"/><path d="m3 21 3-3"/><path d="m3 3 3 3"/><path d="m18 18 3 3"/><path d="m18 6 3-3"/><path d="M2.5 7 7 2.5"/><path d="M17 21.5 21.5 17"/><path d="M11.5 15.5 15.5 11.5"/><path d="M15.5 11.5 11.5 15.5"/><path d="M2.5 7.5 7.5 2.5"/><path d="M16.5 21.5 21.5 16.5"/><path d="m3.5 17.5 3 3"/><path d="m17.5 3.5 3 3"/>
  </svg>
);

export default Dashboard;
