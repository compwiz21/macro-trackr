
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { FoodEntry, DailyGoals, MealCategory } from '../types';
import { Plus, Camera, Trash2, Loader2, X, Calendar, Scale, Utensils, Zap, Image as ImageIcon, RefreshCcw } from 'lucide-react';
import { estimateFoodMacros } from '../services/geminiService';

interface FoodLoggerProps {
  entries: FoodEntry[];
  onAdd: (entry: FoodEntry) => void;
  onRemove: (id: string) => void;
  goals: DailyGoals;
}

const FoodLogger: React.FC<FoodLoggerProps> = ({ entries, onAdd, onRemove, goals }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraMode, setCameraMode] = useState<'user' | 'environment'>('environment');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState({
    name: '',
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    category: 'Breakfast' as MealCategory
  });

  // Filter entries for today only
  const todayEntries = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    return entries.filter(entry => entry.timestamp.startsWith(today));
  }, [entries]);

  const totals = useMemo(() => todayEntries.reduce((acc, curr) => ({
    cal: acc.cal + curr.calories,
    pro: acc.pro + curr.protein,
    car: acc.car + curr.carbs,
    fat: acc.fat + curr.fat
  }), { cal: 0, pro: 0, car: 0, fat: 0 }), [todayEntries]);

  // Handle camera stream lifecycle
  useEffect(() => {
    let stream: MediaStream | null = null;

    const initCamera = async () => {
      if (showCamera) {
        try {
          stream = await navigator.mediaDevices.getUserMedia({ 
            video: { 
              facingMode: cameraMode,
              width: { ideal: 1280 },
              height: { ideal: 720 }
            } 
          });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            await videoRef.current.play();
          }
        } catch (err) {
          console.error("Error accessing camera:", err);
          setShowCamera(false);
        }
      }
    };

    initCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [showCamera, cameraMode]);

  const progress = {
    cal: (totals.cal / goals.calories) * 100,
    pro: (totals.pro / goals.protein) * 100,
    car: (totals.car / goals.carbs) * 100,
    fat: (totals.fat / goals.fat) * 100,
  };

  const openCamera = (mode: 'user' | 'environment') => {
    setCameraMode(mode);
    setShowCamera(true);
  };

  const openAddModal = (category: MealCategory) => {
    setForm({
      name: '',
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      category: category
    });
    setIsAdding(true);
  };

  const processImage = async (base64: string) => {
    setIsAnalyzing(true);
    setIsAdding(true);
    setForm(prev => ({ ...prev, name: 'Analyzing food...', calories: 0, protein: 0, carbs: 0, fat: 0 }));
    
    const estimation = await estimateFoodMacros(base64);
    if (estimation) {
      setForm(prev => ({ ...prev, ...estimation }));
    } else {
      setForm(prev => ({ ...prev, name: '' }));
    }
    setIsAnalyzing(false);
  };

  const captureAndAnalyze = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0);
    }
    
    const base64 = canvas.toDataURL('image/jpeg').split(',')[1];
    setShowCamera(false);
    await processImage(base64);
  };

  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = (reader.result as string).split(',')[1];
      await processImage(base64);
    };
    reader.readAsDataURL(file);
  };

  const meals: MealCategory[] = ['Breakfast', 'Lunch', 'Dinner', 'Snacks'];

  const renderLogs = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300 pb-12">
      {/* AI Scanner Tools */}
      <div className="grid grid-cols-3 gap-3">
        <button 
          onClick={() => openCamera('environment')}
          className="flex flex-col items-center justify-center p-3 bg-zinc-900/60 rounded-2xl border border-zinc-800 hover:bg-zinc-800 transition-colors group"
        >
          <Camera size={20} className="text-red-500 mb-1.5 group-hover:scale-110 transition-transform" />
          <span className="text-[8px] font-bold text-zinc-400 uppercase tracking-tighter">AI Scanner</span>
        </button>
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="flex flex-col items-center justify-center p-3 bg-zinc-900/60 rounded-2xl border border-zinc-800 hover:bg-zinc-800 transition-colors group"
        >
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleGalleryUpload} 
            accept="image/*" 
            className="hidden" 
          />
          <ImageIcon size={20} className="text-blue-400 mb-1.5 group-hover:scale-110 transition-transform" />
          <span className="text-[8px] font-bold text-zinc-400 uppercase tracking-tighter">AI Gallery</span>
        </button>
        <button className="flex flex-col items-center justify-center p-3 bg-zinc-900/60 rounded-2xl border border-zinc-800 hover:bg-zinc-800 transition-colors group">
          <Scale size={20} className="text-green-500 mb-1.5 group-hover:scale-110 transition-transform" />
          <span className="text-[8px] font-bold text-zinc-400 uppercase tracking-tighter">Scale</span>
        </button>
      </div>

      {meals.map(meal => {
        const mealEntries = todayEntries.filter(e => e.category === meal);
        const mealCals = mealEntries.reduce((a, b) => a + b.calories, 0);
        
        return (
          <div key={meal} className="bg-zinc-900/40 border border-zinc-800/50 rounded-3xl overflow-hidden shadow-lg">
            <div className="flex justify-between items-center px-4 py-3 bg-gradient-to-r from-zinc-900 to-zinc-950">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-6 bg-red-600 rounded-full"></div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-white">{meal}</h3>
              </div>
              <div className="flex items-center gap-3">
                <p className="text-xs font-bold text-zinc-500">{mealCals} Calories</p>
                <button 
                  onClick={() => openAddModal(meal)}
                  className="p-1.5 bg-zinc-800 rounded-lg text-red-500 hover:bg-zinc-700 active:scale-95 transition-all shadow-inner border border-zinc-700"
                >
                  <Plus size={16} strokeWidth={3} />
                </button>
              </div>
            </div>
            
            <div className="p-1">
              {mealEntries.length === 0 ? (
                <div className="py-6 text-center opacity-30 text-[10px] font-bold uppercase tracking-widest italic flex flex-col items-center gap-2">
                  <Utensils size={16} />
                  No {meal} logs
                </div>
              ) : (
                mealEntries.map(entry => (
                  <div key={entry.id} className="flex items-center justify-between p-3 hover:bg-zinc-800/30 rounded-2xl transition-colors group">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-lg">
                        {meal === 'Breakfast' ? '🍳' : meal === 'Lunch' ? '🥗' : meal === 'Dinner' ? '🥘' : '🍎'}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-zinc-100">{entry.name}</h4>
                        <p className="text-[9px] text-zinc-500 font-bold uppercase">
                          {entry.calories} Cal • {entry.protein}P • {entry.carbs}C • {entry.fat}F
                        </p>
                      </div>
                    </div>
                    <button onClick={() => onRemove(entry.id)} className="p-2 opacity-0 group-hover:opacity-100 transition-opacity text-zinc-600 hover:text-red-500">
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="flex flex-col h-full bg-[#0d0f14]">
      <div className="px-6 py-4 flex items-center justify-between">
        <h2 className="text-2xl font-oswald font-bold text-white uppercase italic tracking-tighter">
          Fuel Tracker
        </h2>
        <div className="flex items-center gap-1.5 bg-zinc-900 px-3 py-1.5 rounded-full border border-zinc-800">
           <Calendar size={14} className="text-red-500" />
           <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-300">
             {new Date().toLocaleDateString('en-US', { day: '2-digit', month: '2-digit', year: '2-digit' })}
           </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24">
        <div className="bg-gradient-to-br from-zinc-900 via-zinc-900 to-black p-5 rounded-[2.5rem] border border-zinc-800/60 shadow-2xl mb-6 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
            <Zap size={100} />
          </div>
          
          <div className="flex justify-between items-start mb-6">
            <div>
              <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">Calories</p>
              <h3 className="text-4xl font-oswald font-bold text-white leading-none mt-1">
                {totals.cal} <span className={`text-xs ${goals.calories - totals.cal > 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {goals.calories - totals.cal > 0 ? '▼' : '▲'} {Math.abs(goals.calories - totals.cal)} {goals.calories - totals.cal > 0 ? 'left' : 'over'}
                </span>
              </h3>
            </div>
            <div className="flex items-center gap-1 text-[10px] font-bold text-zinc-400 bg-black/40 px-2.5 py-1 rounded-full border border-zinc-800">
              Today
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                <span className="text-zinc-400">Protein</span>
                <span className="text-orange-400">{totals.pro} / {goals.protein}g</span>
              </div>
              <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-orange-600 to-orange-400 transition-all duration-500 rounded-full shadow-[0_0_10px_rgba(251,146,60,0.4)]" 
                  style={{ width: `${Math.min(100, progress.pro)}%` }}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                <span className="text-zinc-400">Fat</span>
                <span className="text-purple-400">{totals.fat} / {goals.fat}g</span>
              </div>
              <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-purple-600 to-purple-400 transition-all duration-500 rounded-full shadow-[0_0_10px_rgba(168,85,247,0.4)]" 
                  style={{ width: `${Math.min(100, progress.fat)}%` }}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                <span className="text-zinc-400">Carbs</span>
                <span className="text-red-400">{totals.car} / {goals.carbs}g</span>
              </div>
              <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-red-700 to-red-500 transition-all duration-500 rounded-full shadow-[0_0_10px_rgba(239,68,68,0.4)]" 
                  style={{ width: `${Math.min(100, progress.car)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {renderLogs()}
      </div>

      {showCamera && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col overflow-hidden">
          <button 
            onClick={() => setShowCamera(false)} 
            className="absolute top-6 left-6 z-[110] p-4 bg-black/60 backdrop-blur-md rounded-full text-white border border-white/20 hover:bg-zinc-800 active:scale-95 transition-all shadow-xl"
          >
            <X size={24} />
          </button>
          
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted 
            className="flex-1 object-cover w-full h-full" 
          />
          
          <div className="p-8 pb-12 bg-zinc-950 flex justify-between items-center border-t border-zinc-800/50">
            <div className="w-12 h-12 flex items-center justify-center">
            </div>
            
            <button 
              onClick={captureAndAnalyze} 
              className="w-20 h-20 bg-white rounded-full border-[6px] border-zinc-400 shadow-xl shadow-white/10 active:scale-90 transition-transform flex items-center justify-center overflow-hidden"
            >
              <div className="w-full h-full bg-red-600 opacity-5 animate-pulse"></div>
              <Camera size={32} className="text-zinc-900 absolute" />
            </button>
            
            <button 
              onClick={() => setCameraMode(prev => prev === 'user' ? 'environment' : 'user')} 
              className="w-12 h-12 flex items-center justify-center bg-zinc-800 rounded-full text-white active:rotate-180 transition-transform duration-500"
            >
              <RefreshCcw size={20} />
            </button>
          </div>
          <canvas ref={canvasRef} className="hidden" />
        </div>
      )}

      {isAdding && (
        <div className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-6 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
          <form onSubmit={(e) => {
            e.preventDefault();
            onAdd({
              id: Math.random().toString(36).substr(2, 9),
              ...form,
              timestamp: new Date().toISOString()
            });
            setIsAdding(false);
          }} className="w-full bg-zinc-900 rounded-[2.5rem] border border-zinc-800 p-8 space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-oswald font-bold uppercase text-white">Log {form.category}</h3>
              <button type="button" onClick={() => setIsAdding(false)} className="text-zinc-500 hover:text-white"><X /></button>
            </div>

            {isAnalyzing && (
              <div className="flex items-center gap-3 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-500">
                <Loader2 className="animate-spin" size={18} />
                <span className="text-[10px] font-bold uppercase tracking-widest">Macho AI is calculating...</span>
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5 block">Category</label>
                <div className="grid grid-cols-2 gap-2">
                  {meals.map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setForm(f => ({ ...f, category: m }))}
                      className={`py-2 text-[9px] font-bold uppercase rounded-lg border transition-all ${form.category === m ? 'bg-red-600 border-red-500 text-white' : 'bg-zinc-800 border-zinc-700 text-zinc-500'}`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5 block">Food Name</label>
                <input 
                  required
                  className="w-full bg-zinc-800 rounded-2xl p-4 text-sm text-white outline-none focus:ring-1 focus:ring-red-500 border border-zinc-700"
                  value={form.name}
                  onChange={e => setForm({...form, name: e.target.value})}
                  placeholder="e.g. Avocado Toast"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5 block">Calories</label>
                  <input 
                    type="number" 
                    inputMode="numeric"
                    className="w-full bg-zinc-800 rounded-2xl p-4 text-white outline-none border border-zinc-700" 
                    value={form.calories === 0 ? '' : form.calories} 
                    onChange={e => setForm({...form, calories: e.target.value === '' ? 0 : Number(e.target.value)})}
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5 block">Protein</label>
                  <input 
                    type="number" 
                    inputMode="numeric"
                    className="w-full bg-zinc-800 rounded-2xl p-4 text-white outline-none border border-zinc-700" 
                    value={form.protein === 0 ? '' : form.protein} 
                    onChange={e => setForm({...form, protein: e.target.value === '' ? 0 : Number(e.target.value)})}
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5 block">Carbs</label>
                  <input 
                    type="number" 
                    inputMode="numeric"
                    className="w-full bg-zinc-800 rounded-2xl p-4 text-white outline-none border border-zinc-700" 
                    value={form.carbs === 0 ? '' : form.carbs} 
                    onChange={e => setForm({...form, carbs: e.target.value === '' ? 0 : Number(e.target.value)})}
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5 block">Fat</label>
                  <input 
                    type="number" 
                    inputMode="numeric"
                    className="w-full bg-zinc-800 rounded-2xl p-4 text-white outline-none border border-zinc-700" 
                    value={form.fat === 0 ? '' : form.fat} 
                    onChange={e => setForm({...form, fat: e.target.value === '' ? 0 : Number(e.target.value)})}
                    placeholder="0"
                  />
                </div>
              </div>
            </div>

            <button type="submit" className="w-full py-5 bg-red-600 rounded-2xl text-white font-oswald font-bold text-xl uppercase shadow-xl shadow-red-900/40 hover:bg-red-700 transition-all">
              Add To Log
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default FoodLogger;
