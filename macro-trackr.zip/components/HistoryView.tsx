
import React from 'react';
import { WorkoutSession } from '../types';
import { Calendar, Clock, Dumbbell, ChevronRight } from 'lucide-react';

interface HistoryViewProps {
  sessions: WorkoutSession[];
}

const HistoryView: React.FC<HistoryViewProps> = ({ sessions }) => {
  const sortedSessions = [...sessions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  if (sessions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-96 p-8 text-center opacity-40">
        <Dumbbell size={64} className="mb-4" />
        <p className="font-bold text-lg uppercase tracking-widest">No history found</p>
        <p className="text-sm mt-2">Finish a workout to see it listed here.</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <h2 className="text-2xl font-oswald font-bold mb-6">WORKOUT JOURNAL</h2>
      
      {sortedSessions.map((session) => (
        <div key={session.id} className="bg-zinc-900/50 rounded-2xl border border-zinc-800 overflow-hidden hover:border-zinc-700 transition-all cursor-pointer group">
          <div className="p-5">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-bold text-white uppercase text-lg leading-tight group-hover:text-red-500 transition-colors">{session.title}</h3>
                <div className="flex items-center gap-3 mt-1 text-zinc-500 text-xs">
                  <div className="flex items-center gap-1">
                    <Calendar size={12} />
                    <span>{new Date(session.date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock size={12} />
                    <span>{session.durationMinutes}m</span>
                  </div>
                </div>
              </div>
              <ChevronRight className="text-zinc-700 group-hover:text-zinc-400" size={20} />
            </div>

            <div className="flex flex-wrap gap-2">
              {session.exercises.slice(0, 3).map((ex) => (
                <span key={ex.id} className="px-2 py-1 bg-zinc-800 rounded text-[10px] text-zinc-400 font-bold uppercase border border-zinc-700">
                  {ex.sets.length}× {ex.name}
                </span>
              ))}
              {session.exercises.length > 3 && (
                <span className="px-2 py-1 bg-zinc-800/30 rounded text-[10px] text-zinc-600 font-bold">
                  +{session.exercises.length - 3} more
                </span>
              )}
            </div>

            <div className="mt-4 pt-4 border-t border-zinc-800 flex justify-between items-end">
              <div>
                <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest">Est. Volume</p>
                <p className="font-oswald text-xl text-white">{session.totalVolume.toLocaleString()} <span className="text-xs text-zinc-600 italic uppercase">{session.unit || 'kg'}</span></p>
              </div>
              <div className="text-[10px] font-bold text-red-500 uppercase bg-red-500/10 px-2 py-1 rounded">
                COMPLETED
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default HistoryView;
