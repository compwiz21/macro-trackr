
import React from 'react';
import { Tab, UserProfile } from '../types';
import { LayoutDashboard, Dumbbell, History, MessageSquare, Utensils, Settings } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  currentUser: UserProfile | null;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab, currentUser }) => {
  const tabs = [
    { id: Tab.DASHBOARD, label: 'Metrics', icon: LayoutDashboard },
    { id: Tab.FUEL, label: 'Fuel', icon: Utensils },
    { id: Tab.WORKOUT, label: 'Lift', icon: Dumbbell },
    { id: Tab.HISTORY, label: 'Journal', icon: History },
    { id: Tab.COACH, label: 'Coach', icon: MessageSquare },
    { id: Tab.SETTINGS, label: 'Config', icon: Settings },
  ];

  return (
    <div className="flex flex-col h-screen bg-black text-white max-w-md mx-auto relative overflow-hidden shadow-2xl">
      <main className="flex-1 overflow-y-auto pb-24">
        {children}
      </main>

      <nav className="fixed bottom-0 w-full max-w-md border-t border-zinc-900 bg-black/80 backdrop-blur-xl flex justify-around items-center py-4 px-2 z-[60]">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center space-y-1 transition-all duration-300 ${
                isActive ? 'text-red-500 scale-110' : 'text-zinc-600 hover:text-zinc-400'
              }`}
            >
              <div className={`p-1 rounded-lg ${isActive ? 'bg-red-500/10' : ''}`}>
                <Icon size={20} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className="text-[9px] font-bold uppercase tracking-widest">{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default Layout;
