
import React, { useState } from 'react';
import { DailyGoals, WeightUnit, UserProfile } from '../types';
// Added missing Loader2 import from lucide-react
import { Target, Zap, Droplets, Pizza, Scale, User, LogOut, ChevronRight, Users, ArrowLeft, Save, ShieldCheck, Mail, Lock, Eye, EyeOff, Loader2 } from 'lucide-react';

interface SettingsProps {
  goals: DailyGoals;
  onUpdateGoals: (goals: DailyGoals) => void;
  unit: WeightUnit;
  onUpdateUnit: (unit: WeightUnit) => void;
  onSwitchAccount: () => void;
  currentUser: UserProfile;
  onUpdateUser: (updates: Partial<UserProfile>) => void;
}

const Settings: React.FC<SettingsProps> = ({ goals, onUpdateGoals, unit, onUpdateUnit, onSwitchAccount, currentUser, onUpdateUser }) => {
  const [view, setView] = useState<'MAIN' | 'PROFILE'>('MAIN');
  const [editName, setEditName] = useState(currentUser.name);
  const [editPassword, setEditPassword] = useState(currentUser.password || '');
  const [showPassword, setShowPassword] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleGoalChange = (key: keyof DailyGoals, value: string) => {
    const numValue = value === '' ? 0 : Number(value);
    onUpdateGoals({ ...goals, [key]: numValue });
  };

  const handleSaveProfile = () => {
    setIsSaving(true);
    setTimeout(() => {
      onUpdateUser({
        name: editName,
        password: editPassword
      });
      setIsSaving(false);
      setView('MAIN');
    }, 600);
  };

  if (view === 'PROFILE') {
    return (
      <div className="p-6 space-y-8 animate-in slide-in-from-right-4 duration-300">
        <header className="flex items-center gap-4">
          <button 
            onClick={() => setView('MAIN')}
            className="p-2 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 hover:text-white transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h2 className="text-2xl font-oswald font-bold uppercase italic tracking-tight leading-none text-white">Athlete Bio</h2>
            <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mt-1">Manage Trackr Bio</p>
          </div>
        </header>

        <section className="flex flex-col items-center py-6">
          <div className={`w-28 h-28 ${currentUser.avatarColor} rounded-[2rem] flex items-center justify-center text-white font-oswald font-bold text-5xl shadow-2xl shadow-red-900/20 rotate-3`}>
            {editName[0]?.toUpperCase() || 'A'}
          </div>
          <div className="mt-6 flex flex-col items-center gap-1">
            <span className="text-xs font-bold text-zinc-500 uppercase tracking-[0.3em]">Trackr Status</span>
            {currentUser.googleId ? (
              <div className="flex items-center gap-2 px-4 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-500 text-[10px] font-bold uppercase tracking-widest">
                <ShieldCheck size={12} /> Google Linked
              </div>
            ) : (
              <div className="flex items-center gap-2 px-4 py-1.5 bg-red-500/10 border border-red-500/20 rounded-full text-red-500 text-[10px] font-bold uppercase tracking-widest">
                <Lock size={12} /> Trackr Internal
              </div>
            )}
          </div>
        </section>

        <section className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Athlete Handle</label>
            <div className="relative">
              <input 
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full bg-zinc-900/50 border border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none focus:ring-1 focus:ring-red-500 transition-all"
              />
              <User size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-700" />
            </div>
          </div>

          {!currentUser.googleId && (
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Access Code</label>
              <div className="relative">
                <input 
                  type={showPassword ? "text" : "password"}
                  value={editPassword}
                  onChange={(e) => setEditPassword(e.target.value)}
                  className="w-full bg-zinc-900/50 border border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none focus:ring-1 focus:ring-red-500 transition-all"
                />
                <button 
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-700 hover:text-zinc-500"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>
          )}
        </section>

        <section className="pt-8">
          <button 
            onClick={handleSaveProfile}
            disabled={isSaving}
            className="w-full bg-red-600 text-white font-oswald font-bold py-5 rounded-2xl uppercase tracking-widest text-lg shadow-xl shadow-red-900/20 active:scale-95 transition-all flex items-center justify-center gap-3 disabled:bg-zinc-800"
          >
            {isSaving ? <Loader2 size={24} className="animate-spin" /> : <><Save size={24} /> Update Bio</>}
          </button>
        </section>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <header className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-oswald font-bold uppercase italic tracking-tight text-white">App Calibration</h2>
          <p className="text-xs text-zinc-500 font-bold uppercase tracking-widest mt-1 text-white">Athlete: <span className="text-red-500">{currentUser.name}</span></p>
        </div>
        <button 
          onClick={onSwitchAccount}
          className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-[10px] font-bold uppercase tracking-widest text-zinc-400 hover:text-white transition-all"
        >
          <Users size={14} /> Switch
        </button>
      </header>

      <section className="space-y-4">
        <h3 className="text-[10px] font-bold text-zinc-400 uppercase tracking-[0.2em] px-1 flex items-center gap-2">
          <Target size={12} className="text-red-500" /> Target Calibration
        </h3>
        
        <div className="bg-zinc-900/40 border border-zinc-800 rounded-[2.5rem] p-6 space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest flex justify-between">
              <span>Calories (kcal)</span>
              <span className="text-white">{goals.calories}</span>
            </label>
            <input 
              type="number"
              inputMode="numeric"
              value={goals.calories === 0 ? '' : goals.calories}
              onChange={(e) => handleGoalChange('calories', e.target.value)}
              placeholder="0"
              className="w-full bg-zinc-800/50 rounded-2xl p-4 text-white font-oswald text-xl focus:outline-none focus:ring-1 focus:ring-red-500 border border-zinc-800 transition-all shadow-inner"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-2">
              <label className="text-[9px] font-bold text-zinc-500 uppercase tracking-tighter flex items-center gap-1">
                <Zap size={10} className="text-orange-400" /> Protein (g)
              </label>
              <input 
                type="number"
                inputMode="numeric"
                value={goals.protein === 0 ? '' : goals.protein}
                onChange={(e) => handleGoalChange('protein', e.target.value)}
                placeholder="0"
                className="w-full bg-zinc-800/50 rounded-xl p-3 text-white font-oswald text-lg focus:outline-none focus:ring-1 focus:ring-red-500 border border-zinc-800"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[9px] font-bold text-zinc-500 uppercase tracking-tighter flex items-center gap-1">
                <Pizza size={10} className="text-red-400" /> Carbs (g)
              </label>
              <input 
                type="number"
                inputMode="numeric"
                value={goals.carbs === 0 ? '' : goals.carbs}
                onChange={(e) => handleGoalChange('carbs', e.target.value)}
                placeholder="0"
                className="w-full bg-zinc-800/50 rounded-xl p-3 text-white font-oswald text-lg focus:outline-none focus:ring-1 focus:ring-red-500 border border-zinc-800"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[9px] font-bold text-zinc-500 uppercase tracking-tighter flex items-center gap-1">
                <Droplets size={10} className="text-purple-400" /> Fat (g)
              </label>
              <input 
                type="number"
                inputMode="numeric"
                value={goals.fat === 0 ? '' : goals.fat}
                onChange={(e) => handleGoalChange('fat', e.target.value)}
                placeholder="0"
                className="w-full bg-zinc-800/50 rounded-xl p-3 text-white font-oswald text-lg focus:outline-none focus:ring-1 focus:ring-red-500 border border-zinc-800"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="space-y-4">
        <h3 className="text-[10px] font-bold text-zinc-400 uppercase tracking-[0.2em] px-1">Global Preferences</h3>
        <div className="bg-zinc-900/40 border border-zinc-800 rounded-3xl overflow-hidden">
          <div className="flex items-center justify-between p-5 border-b border-zinc-800/50">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400">
                <Scale size={16} />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-white">Mass Unit</span>
            </div>
            <div className="flex bg-zinc-800 p-1 rounded-xl">
              <button 
                onClick={() => onUpdateUnit('kg')}
                className={`px-4 py-1.5 text-[10px] font-bold rounded-lg transition-all ${unit === 'kg' ? 'bg-red-600 text-white shadow-lg' : 'text-zinc-500'}`}
              >
                KG
              </button>
              <button 
                onClick={() => onUpdateUnit('lbs')}
                className={`px-4 py-1.5 text-[10px] font-bold rounded-lg transition-all ${unit === 'lbs' ? 'bg-red-600 text-white shadow-lg' : 'text-zinc-500'}`}
              >
                LBS
              </button>
            </div>
          </div>
          
          <button 
            onClick={() => setView('PROFILE')}
            className="w-full flex items-center justify-between p-5 hover:bg-zinc-800/30 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400">
                <User size={16} />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-white">Athlete Profile</span>
            </div>
            <ChevronRight size={16} className="text-zinc-600" />
          </button>
        </div>
      </section>

      <section className="pt-4 space-y-3">
        <button 
          onClick={onSwitchAccount}
          className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-zinc-900 border border-zinc-800 text-zinc-400 text-[10px] font-bold uppercase tracking-[0.2em] hover:text-white transition-colors"
        >
          <Users size={14} /> Switch Account
        </button>
        <button className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-zinc-900/20 border border-zinc-800/50 text-zinc-700 text-[10px] font-bold uppercase tracking-[0.2em] hover:text-red-800 transition-colors">
          <LogOut size={14} /> Clear Local Data
        </button>
      </section>

      <div className="bg-red-600/5 border border-red-500/10 p-5 rounded-3xl text-center">
        <p className="text-[10px] font-medium text-red-400/60 italic uppercase tracking-widest">Trackr Core Engine v4.0.0-PRO</p>
      </div>
    </div>
  );
};

export default Settings;
