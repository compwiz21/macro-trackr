
import React, { useState, useEffect } from 'react';
import { WorkoutSession, ExerciseLog, Set, WeightUnit, WorkoutPlan } from '../types';
import { DEFAULT_EXERCISES } from '../constants';
import { Plus, Trash2, CheckCircle2, Save, X, Search, Clock, Zap } from 'lucide-react';

interface WorkoutLoggerProps {
  onSave: (session: WorkoutSession) => void;
  onCancel: () => void;
  defaultUnit: WeightUnit;
  initialPlan?: WorkoutPlan;
}

const WorkoutLogger: React.FC<WorkoutLoggerProps> = ({ onSave, onCancel, defaultUnit, initialPlan }) => {
  const [exercises, setExercises] = useState<ExerciseLog[]>([]);
  const [showPicker, setShowPicker] = useState(false);
  const [search, setSearch] = useState('');
  const [startTime] = useState(Date.now());
  const [manualDuration, setManualDuration] = useState<number | null>(null);
  const [unit, setUnit] = useState<WeightUnit>(defaultUnit);

  useEffect(() => {
    if (initialPlan && initialPlan.exercises.length > 0) {
      const planExercises: ExerciseLog[] = initialPlan.exercises.map(name => ({
        id: Math.random().toString(36).substr(2, 9),
        name,
        sets: [{ id: Math.random().toString(36).substr(2, 9), reps: 0, weight: 0, completed: false }]
      }));
      setExercises(planExercises);
    }
  }, [initialPlan]);

  const addExercise = (name: string) => {
    const newExercise: ExerciseLog = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      sets: [{ id: Math.random().toString(36).substr(2, 9), reps: 0, weight: 0, completed: false }]
    };
    setExercises([...exercises, newExercise]);
    setShowPicker(false);
    setSearch('');
  };

  const updateSet = (exerciseId: string, setId: string, updates: Partial<Set>) => {
    setExercises(prev => prev.map(ex => {
      if (ex.id !== exerciseId) return ex;
      return {
        ...ex,
        sets: ex.sets.map(s => s.id === setId ? { ...s, ...updates } : s)
      };
    }));
  };

  const addSet = (exerciseId: string) => {
    setExercises(prev => prev.map(ex => {
      if (ex.id !== exerciseId) return ex;
      const lastSet = ex.sets[ex.sets.length - 1];
      const newSet: Set = {
        id: Math.random().toString(36).substr(2, 9),
        reps: lastSet?.reps || 0,
        weight: lastSet?.weight || 0,
        completed: false
      };
      return { ...ex, sets: [...ex.sets, newSet] };
    }));
  };

  const removeSet = (exerciseId: string, setId: string) => {
    setExercises(prev => prev.map(ex => {
      if (ex.id !== exerciseId) return ex;
      if (ex.sets.length <= 1) return ex;
      return { ...ex, sets: ex.sets.filter(s => s.id !== setId) };
    }));
  };

  const removeExercise = (exerciseId: string) => {
    setExercises(prev => prev.filter(ex => ex.id !== exerciseId));
  };

  const currentDurationDisplay = manualDuration !== null ? manualDuration : Math.floor((Date.now() - startTime) / 60000);

  const handleSave = () => {
    if (exercises.length === 0) return;
    
    const totalVolume = exercises.reduce((acc, ex) => 
      acc + ex.sets.reduce((sAcc, s) => sAcc + (s.reps * s.weight), 0), 0
    );

    const session: WorkoutSession = {
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toISOString(),
      title: initialPlan ? initialPlan.title : `${new Date().toLocaleDateString('en-US', { weekday: 'long' })} Session`,
      durationMinutes: currentDurationDisplay,
      exercises,
      totalVolume,
      unit
    };

    onSave(session);
  };

  const filteredExercises = DEFAULT_EXERCISES.filter(e => 
    e.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 pb-32">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-oswald font-bold uppercase italic text-red-500">
          {initialPlan ? 'ACTIVE PLAN' : 'New Session'}
        </h2>
        <button onClick={onCancel} className="p-2 text-zinc-500 hover:text-white transition-colors">
          <X size={24} />
        </button>
      </div>

      {initialPlan && (
        <div className="mb-6 flex items-center gap-2 px-3 py-2 bg-red-600/10 border border-red-500/30 rounded-xl">
          <Zap size={14} className="text-red-500" />
          <span className="text-[10px] font-bold text-red-500 uppercase tracking-widest">Training synced from Coach Macho</span>
        </div>
      )}

      <div className="flex gap-4 mb-6">
        <div className="flex-1 bg-zinc-900 rounded-2xl p-4 border border-zinc-800 flex items-center gap-3">
          <Clock className="text-zinc-500" size={18} />
          <div className="flex-1">
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1">Duration (Min)</p>
            <input 
              type="number"
              inputMode="numeric"
              value={manualDuration === 0 ? '' : (manualDuration || '')}
              placeholder={Math.floor((Date.now() - startTime) / 60000).toString()}
              onChange={(e) => setManualDuration(e.target.value === '' ? null : Number(e.target.value))}
              className="bg-transparent text-white font-oswald text-xl w-full focus:outline-none"
            />
          </div>
        </div>
        <div className="bg-zinc-900 rounded-2xl p-2 border border-zinc-800 flex flex-col justify-center items-center px-4">
          <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Unit</p>
          <div className="flex bg-zinc-800 p-1 rounded-lg">
            <button 
              onClick={() => setUnit('kg')}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${unit === 'kg' ? 'bg-red-600 text-white' : 'text-zinc-500'}`}
            >
              KG
            </button>
            <button 
              onClick={() => setUnit('lbs')}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${unit === 'lbs' ? 'bg-red-600 text-white' : 'text-zinc-500'}`}
            >
              LBS
            </button>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {exercises.map((ex) => (
          <div key={ex.id} className="bg-zinc-900 rounded-2xl border border-zinc-800 overflow-hidden shadow-lg">
            <div className="bg-zinc-800/50 p-4 flex justify-between items-center">
              <h3 className="font-bold text-white uppercase tracking-wider">{ex.name}</h3>
              <button onClick={() => removeExercise(ex.id)} className="text-zinc-500 hover:text-red-500">
                <Trash2 size={18} />
              </button>
            </div>
            
            <div className="p-4 space-y-4">
              <div className="grid grid-cols-5 gap-2 text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-center">
                <span>Set</span>
                <span>{unit.toUpperCase()}</span>
                <span>Reps</span>
                <span className="col-span-2">Done</span>
              </div>
              
              {ex.sets.map((set, idx) => (
                <div key={set.id} className={`grid grid-cols-5 gap-2 items-center transition-opacity duration-200 ${set.completed ? 'opacity-50' : ''}`}>
                  <span className="text-center font-oswald font-bold text-zinc-400">{idx + 1}</span>
                  <input
                    type="number"
                    inputMode="numeric"
                    value={set.weight === 0 ? '' : set.weight}
                    placeholder="0"
                    onChange={(e) => updateSet(ex.id, set.id, { weight: e.target.value === '' ? 0 : Number(e.target.value) })}
                    className="bg-zinc-800 rounded-lg p-2 text-center text-sm font-medium focus:outline-none focus:ring-1 focus:ring-red-500 w-full shadow-inner border border-zinc-700/50"
                  />
                  <input
                    type="number"
                    inputMode="numeric"
                    value={set.reps === 0 ? '' : set.reps}
                    placeholder="0"
                    onChange={(e) => updateSet(ex.id, set.id, { reps: e.target.value === '' ? 0 : Number(e.target.value) })}
                    className="bg-zinc-800 rounded-lg p-2 text-center text-sm font-medium focus:outline-none focus:ring-1 focus:ring-red-500 w-full shadow-inner border border-zinc-700/50"
                  />
                  <div className="flex justify-center gap-1 col-span-2">
                    <button 
                      onClick={() => updateSet(ex.id, set.id, { completed: !set.completed })}
                      className={`p-2 rounded-lg transition-colors ${set.completed ? 'bg-green-600 text-white' : 'bg-zinc-800 text-zinc-600 border border-zinc-700/50'}`}
                    >
                      <CheckCircle2 size={18} />
                    </button>
                    <button onClick={() => removeSet(ex.id, set.id)} className="p-2 text-zinc-600 hover:text-zinc-400">
                      <X size={16} />
                    </button>
                  </div>
                </div>
              ))}

              <button 
                onClick={() => addSet(ex.id)}
                className="w-full py-2 bg-zinc-800 hover:bg-zinc-700 rounded-xl text-xs font-bold uppercase tracking-widest transition-colors border border-zinc-700/50"
              >
                + Add Set
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 flex flex-col gap-4">
        <button 
          onClick={() => setShowPicker(true)}
          className="flex items-center justify-center gap-2 w-full py-4 bg-zinc-900 border border-zinc-800 rounded-2xl text-red-500 font-bold uppercase tracking-widest hover:border-red-500/50 transition-all shadow-lg"
        >
          <Plus size={20} /> Add Exercise
        </button>

        {exercises.length > 0 && (
          <button 
            onClick={handleSave}
            className="flex items-center justify-center gap-2 w-full py-5 bg-red-600 rounded-2xl text-white font-oswald font-bold text-xl uppercase tracking-tighter hover:bg-red-700 shadow-xl shadow-red-900/20 active:scale-95 transition-all"
          >
            <Save size={24} /> Finish Workout
          </button>
        )}
      </div>

      {showPicker && (
        <div className="fixed inset-0 bg-black/90 z-[60] flex flex-col p-6 overflow-y-auto backdrop-blur-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-oswald font-bold uppercase text-white tracking-wider">Select Exercise</h3>
            <button onClick={() => setShowPicker(false)} className="p-2 text-zinc-500 hover:text-white transition-colors"><X /></button>
          </div>
          
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
            <input 
              autoFocus
              className="w-full bg-zinc-900 rounded-2xl py-4 pl-12 pr-4 text-white focus:ring-1 focus:ring-red-500 outline-none border border-zinc-800 shadow-xl"
              placeholder="Search movement..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 gap-2">
            {filteredExercises.map(e => (
              <button
                key={e.name}
                onClick={() => addExercise(e.name)}
                className="p-5 text-left bg-zinc-900 hover:bg-zinc-800 rounded-2xl border border-zinc-800 transition-colors flex justify-between items-center group shadow-md"
              >
                <div>
                  <div className="font-bold text-white group-hover:text-red-500 transition-colors uppercase tracking-wide">{e.name}</div>
                  <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mt-1">{e.category}</div>
                </div>
                <Plus size={16} className="text-zinc-600 group-hover:text-red-500 transition-colors" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkoutLogger;
