
import { Exercise } from './types';

export const DEFAULT_EXERCISES: Exercise[] = [
  { name: 'Bench Press', category: 'Chest', targetMuscles: ['Chest', 'Triceps', 'Shoulders'] },
  { name: 'Squat', category: 'Legs', targetMuscles: ['Quads', 'Glutes', 'Hamstrings'] },
  { name: 'Deadlift', category: 'Back', targetMuscles: ['Lower Back', 'Hamstrings', 'Glutes'] },
  { name: 'Overhead Press', category: 'Shoulders', targetMuscles: ['Shoulders', 'Triceps'] },
  { name: 'Pull Ups', category: 'Back', targetMuscles: ['Lats', 'Biceps'] },
  { name: 'Barbell Row', category: 'Back', targetMuscles: ['Lats', 'Upper Back'] },
  { name: 'Bicep Curls', category: 'Arms', targetMuscles: ['Biceps'] },
  { name: 'Tricep Extension', category: 'Arms', targetMuscles: ['Triceps'] },
  { name: 'Leg Press', category: 'Legs', targetMuscles: ['Quads'] },
  { name: 'Lat Pulldown', category: 'Back', targetMuscles: ['Lats'] },
];

export const APP_NAME = "Macro Trackr";
