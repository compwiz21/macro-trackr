
import { GoogleGenAI, Type } from "@google/genai";

// Standard client for non-billing-restricted tasks
const getClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAIAdvice = async (history: any[], prompt: string) => {
  try {
    const ai = getClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `User Context: ${JSON.stringify(history)}. User Question: ${prompt}`,
      config: {
        systemInstruction: `You are 'Coach Trackr', a high-energy, data-driven, and extremely knowledgeable fitness trainer. 
        You represent the 'Macro Trackr' app. You give brief, actionable, and motivating advice. 
        Focus on progressive overload, nutritional precision, and form. Use high-performance terminology.
        
        CRITICAL: If you suggest a specific workout routine or a list of exercises, 
        at the very end of your response, include the list of exercises inside <plan> tags, 
        separated by pipes. Example: <plan>Bench Press|Squats|Deadlift</plan>. 
        Only include the exercise names inside the tag.`,
        temperature: 0.8,
      },
    });
    return response.text;
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    if (error.message?.includes("Requested entity was not found")) {
      await handleKeyReauth();
    }
    return "Listen up, athlete! My connection is flickering, but your goals aren't. Stay focused and keep tracking!";
  }
};

export const handleKeyReauth = async () => {
  if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
    await window.aistudio.openSelectKey();
  }
};

export const checkHasKey = async () => {
  if (window.aistudio && typeof window.aistudio.hasSelectedApiKey === 'function') {
    return await window.aistudio.hasSelectedApiKey();
  }
  return true; // Fallback for environments without the helper
};

export const generateMotivationVideo = async (prompt: string) => {
  const ai = getClient();
  try {
    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: `A high-intensity, cinematic, motivational fitness video for the Macro Trackr brand: ${prompt}. Cinematic lighting, 4k, ultra-realistic.`,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });

    return operation;
  } catch (error: any) {
    console.error("Video Generation Error:", error);
    if (error.message?.includes("Requested entity was not found")) {
      await handleKeyReauth();
    }
    throw error;
  }
};

export const estimateFoodMacros = async (base64Image: string) => {
  try {
    const ai = getClient();
    const imagePart = {
      inlineData: {
        data: base64Image,
        mimeType: 'image/jpeg',
      },
    };
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { 
        parts: [
          imagePart, 
          { text: "Estimate the calories and macros (protein, carbs, fat in grams) for the food in this image for the Macro Trackr app. Provide the name of the food too. Return as JSON." }
        ] 
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            calories: { type: Type.NUMBER },
            protein: { type: Type.NUMBER },
            carbs: { type: Type.NUMBER },
            fat: { type: Type.NUMBER }
          },
          required: ["name", "calories", "protein", "carbs", "fat"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Vision Error:", error);
    return null;
  }
};
