
export interface UserProfile {
  id: string;
  name: string;
  avatarColor: string;
  password?: string;
  rememberPassword?: boolean;
  googleId?: string;
  email?: string;
}

export interface Set {
  id: string;
  reps: number;
  weight: number;
  completed: boolean;
}

export interface ExerciseLog {
  id: string;
  name: string;
  sets: Set[];
}

export interface WorkoutSession {
  id: string;
  date: string;
  title: string;
  durationMinutes: number;
  exercises: ExerciseLog[];
  totalVolume: number;
  unit: 'kg' | 'lbs';
}

export interface WorkoutPlan {
  title: string;
  exercises: string[];
}

export type MealCategory = 'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks';

export interface FoodEntry {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  category: MealCategory;
  timestamp: string;
}

export interface DailyGoals {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export enum Tab {
  DASHBOARD = 'DASHBOARD',
  FUEL = 'FUEL',
  WORKOUT = 'WORKOUT',
  HISTORY = 'HISTORY',
  COACH = 'COACH',
  SETTINGS = 'SETTINGS'
}

export interface Exercise {
  name: string;
  category: string;
  targetMuscles: string[];
}

export type WeightUnit = 'kg' | 'lbs';
